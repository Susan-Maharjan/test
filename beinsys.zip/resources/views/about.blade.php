@extends('layouts.master')

@section('content')

    <section class="template">
        <div class="template-container" style="background-image:url('assets/images/about-bg.png')">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <article class="template-content">
                            <h1>About Us</h1>
                            <p>Blanditiis pellentesque Interdum lorem Cras porta, amet nam, animi lectus autem magnam! Venenatis nonummy labore interdum, excepteur lacinia litora, taciti, sint! Placerat numquam reiciendis.</p>
                            <a href="#" class="btn btn-white">View Projects</a>
                        </article>
                    </div>
                    <div class="col-lg-4">
                        <figure class="template-image">
                            <img src="assets/images/banner-svg.svg" class="img-fluid" alt="beinsys">
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="mission">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <article class="mission-head">
                        <h3 class="text-center">Our Mission</h3>
                        <h4>Lacinia semper distinctio earum tincidunt sit, quia voluptas viverra, magna assumenda, pellentesque? Do magni, sapien sint, totam. Rhoncus? Ad, cupidatat, dolore mollit parturient.</h4>
                    </article>
                    <div class="row">
                        <div class="col-md-6">
                            <article class="mission-content">
                                <p>Varius incidunt sapien dolore molestias ultricies platea fermentum lorem. Aliqua dolorem dolorem vestibulum facere ullam? Fermentum anim fugiat? Rhoncus, facilisi natus. Habitasse nulla, tincidunt, blanditiis, natus quam, minim molestias. Illo.</p>
                            </article>
                        </div>
                        <div class="col-md-6">
                            <article class="mission-content">
                                <p>Varius incidunt sapien dolore molestias ultricies platea fermentum lorem. Aliqua dolorem dolorem vestibulum facere ullam? Fermentum anim fugiat? Rhoncus, facilisi natus. Habitasse nulla, tincidunt, blanditiis, natus quam, minim molestias. Illo.</p>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="workprocess">
        <div class="container">
            <article class="mission-head">
                <h3 class="text-center">Work Process</h3>
            </article>
            <div class="row">
                <div class="col-lg-4">
                    <div class="workprocess-block">
                        <figure class="workprocess-icon">
                            <img src="assets/images/research.png" class="img-fluid" alt="beinsys">
                        </figure>
                        <article class="workprocess-text">
                            <h4>01. Research</h4>
                            <p>Quaerat distinctio montes erat viverra mi alias? Cillum voluptas consectetur, pariatur suspendisse.</p>
                        </article>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="workprocess-block">
                        <figure class="workprocess-icon">
                            <img src="assets/images/analyze.png" class="img-fluid" alt="beinsys">
                        </figure>
                        <article class="workprocess-text">
                            <h4>02. Concept Analyze</h4>
                            <p>Quaerat distinctio montes erat viverra mi alias? Cillum voluptas consectetur, pariatur suspendisse.</p>
                        </article>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="workprocess-block">
                        <figure class="workprocess-icon">
                            <img src="assets/images/design.png" class="img-fluid" alt="beinsys">
                        </figure>
                        <article class="workprocess-text">
                            <h4>03. Design</h4>
                            <p>Quaerat distinctio montes erat viverra mi alias? Cillum voluptas consectetur, pariatur suspendisse.</p>
                        </article>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="workprocess-block">
                        <figure class="workprocess-icon">
                            <img src="assets/images/code.png" class="img-fluid" alt="beinsys">
                        </figure>
                        <article class="workprocess-text">
                            <h4>04. Code</h4>
                            <p>Quaerat distinctio montes erat viverra mi alias? Cillum voluptas consectetur, pariatur suspendisse.</p>
                        </article>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="workprocess-block">
                        <figure class="workprocess-icon">
                            <img src="assets/images/test.png" class="img-fluid" alt="beinsys">
                        </figure>
                        <article class="workprocess-text">
                            <h4>05. Test</h4>
                            <p>Quaerat distinctio montes erat viverra mi alias? Cillum voluptas consectetur, pariatur suspendisse.</p>
                        </article>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="workprocess-block">
                        <figure class="workprocess-icon">
                            <img src="assets/images/deliver.png" class="img-fluid" alt="beinsys">
                        </figure>
                        <article class="workprocess-text">
                            <h4>06. Deliver</h4>
                            <p>Quaerat distinctio montes erat viverra mi alias? Cillum voluptas consectetur, pariatur suspendisse.</p>
                        </article>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="records">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="stats-box text-center">
                        <figure class="stats-icon">
                            <img src="assets/images/idea.svg" class="img-fluid" alt="Beinsys">
                        </figure>
                        <article>
                            <h1 class="stats-number">243+</h1>
                            <p class="stats-heading">Completed Projects</p>
                        </article>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="stats-box text-center records-border">
                        <figure class="stats-icon">
                            <img src="assets/images/cctv-headquarters.svg" class="img-fluid" alt="Beinsys">
                        </figure>
                        <article>
                            <h1 class="stats-number">21</h1>
                            <p class="stats-heading">Headquarters</p>
                        </article>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="stats-box text-center">
                        <figure class="stats-icon">
                            <img src="assets/images/team.svg" class="img-fluid" alt="Beinsys">
                        </figure>
                        <article>
                            <h1 class="stats-number">178 k</h1>
                            <p class="stats-heading">Worldwide Users</p>
                        </article>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
