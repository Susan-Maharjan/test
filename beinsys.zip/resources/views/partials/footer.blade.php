<footer class="footer" style="background-image:url('assets/images/footercurve.png')">
    <div class="container">
        <div class="row">
            <div class="footer-content">
                <div class="footer-addressbox text-center">
                    <figure class="footer-logo">
                        <img src="assets/images/logo.png" class="img-fluid" alt="beinsys">
                    </figure>
                    <address>
                            <span>
                            </span><br>
                        1702 Olympic Blvd Santa Monica, CA 90404 <br>
                        +91554866458, 91554855865 <br>
                        info@beinsys.com
                    </address>
                </div>
                <div class="footer-social text-center">
                    <h4 class="footer-heading">Follow us</h4>
                    <ul class="footer-list">
                        <li><i class="fab fa-facebook-f"></i></li>
                        <li><i class="fab fa-twitter"></i></li>
                        <li><i class="fab fa-instagram"></i></li>
                        <li><i class="fab fa-linkedin-in"></i></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class="footer-copyright">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <span class="copyright-text">2019 all rights reserved beinsys</span>
            </div>
            <div class="col-lg-6">
                <div class="footer-menu text-right">
                    <ul class="footer-menulist">
                        <li><a href="{{ URL::to('/') }}">Home</a></li>
                        <li><a href="{{ URL::to('about') }}">About</a></li>
                        <li><a href="{{ URL::to('service') }}">Service</a></li>
                        <li><a href="{{ URL::to('price') }}">Price</a></li>
                        <li><a href="{{ URL::to('testimonial') }}">Testimonials</a></li>
                        <li><a href="{{ URL::to('contact') }}">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript" src="assets/bower_components/jquery/dist/jquery.min.js"></script>
<script type="text/javascript" src="assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/bower_components/slick-carousel/slick/slick.js"></script>
<script src="assets/bower_components/wow/dist/wow.min.js"></script>
<script>
    $(document).ready(function(){
        $('.banner-slider').slick({
            infinite: true,
            arrows: false,
            fade: true,
            slidesToShow: 1,
            slidesToScroll: 1
        });
        $('.factory-slider').slick({
            infinite: true,
            arrows: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            fade: true
        });
        $('.testimonial-slider').slick({
            infinite: true,
            arrows: false,
            dots: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            fade: true
        });
        $('.review-slider').slick({
            infinite: true,
            arrows: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            fade: true
        });
    });
</script>
<script>
    new WOW().init();
</script>

