@extends('layouts.master')
@section('content')
    <section class="template testimonial-template">
        <div class="template-container" style="background-image:url('assets/images/about-bg.png')">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <article class="template-content">
                            <h1>We Are The Best At What We Do</h1>
                            <p>Sagittis semper quod quo nibh venenatis quae possimus, cupidatat habitant vivamus ac distinctio cum assumenda anim modi sapiente voluptates.</p>
                            <a href="#" class="btn btn-white">Talk to Us</a>
                        </article>
                    </div>
                    <div class="col-lg-6">
                        <figure class="template-image">
                            <img src="assets/images/banner-svg.svg" class="img-fluid" alt="beinsys">
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="review">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <article class="review-content text-center">
                        <h3>Some words from our happy clients</h3>
                        <p>Sagittis semper quod quo nibh venenatis quae possimus, cupidatat habitant vivamus ac distinctio cum assumenda anim modi sapiente voluptates.</p>
                    </article>
                    <div class="review-slider">
                        <div class="review-item">
                            <figure class="review-image">
                                <img src="assets/images/client1.jpg" class="img-fluid" alt="beinsys">
                            </figure>
                            <figcaption class="review-words">
                                <h4>Marie Smith</h4>
                                <span>Marketing Manager</span>
                                <p>Arcu eum assumenda, laborum possimus habitasse parturient illum quod? Nisl augue aliquet! Magnam facilis adipisicing, assumenda, ipsam <br> Delectus cumque integer Arcu eum assumenda, laborum possimus habitasse parturient illum quod? Nisl augue aliquet</p>
                            </figcaption>
                        </div>
                        <div class="review-item">
                            <figure class="review-image">
                                <img src="assets/images/client2.jpg" class="img-fluid" alt="beinsys">
                            </figure>
                            <figcaption class="review-words">
                                <h4>John Doe</h4>
                                <span>Marketing Manager</span>
                                <p>Arcu eum assumenda, laborum possimus habitasse parturient illum quod? Nisl augue aliquet! Magnam facilis adipisicing, assumenda, ipsam <br> Delectus cumque integer Arcu eum assumenda, laborum possimus habitasse parturient illum quod? Nisl augue aliquet</p>
                            </figcaption>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
