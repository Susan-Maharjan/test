@extends('layouts.master')

@section('title')
    Beinsys
@endsection

@section('content')
    <section class="banner">
        <div class="banner-content">
            <div class="container">
            <div class="row">
                <div class="col-lg-6">
                <article class="banner-textcontent">
                    <h1 class="banner-text">Get Inspired</h1>
                    <h5 class="banner-text subtext">Find the website design <br> that speaks to you.</h5>
                    <a href="{{ URL::to('contact') }}" class="btn btn-white">Contact Now</a>
                </article>
                </div>
                <div class="col-lg-6">
                <div class="banner-slider">
                    <div class="banner-item">
                        <figure>
                            <img src="assets/images/banner-svg.svg">
                        </figure>
                    </div>
                    {{-- <div class="banner-item">
                        <figure>
                            <img src="assets/images/banner-svg.svg">
                        </figure>
                    </div>
                    <div class="banner-item">
                        <figure>
                            <img src="assets/images/banner-svg.svg">
                        </figure>
                    </div> --}}
                </div>
                </div>
            </div>
            </div>
        </div>
    </section>
    <div class="curve">
      <figure>
        <img src="assets/images/curve.svg">
      </figure>
    </div>
    <section class="service">
      <div class="container">
        <div class="row">
          <div class="col-lg-10 offset-lg-1">
            <div class="row">
              <div class="col-lg-9">
                <div class="row">
                  <div class="col-md-6">
                    <a href="#" class="service-item wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="0.5s">
                      <figure class="service-icon">
                        <img src="assets/images/web.svg" class="img-fluid" alt="Beinsys">
                      </figure>
                      <h4>Web Development</h4>
                      <p>Get awesome for your product or service.</p>
                    </a>
                      <a href="#" class="service-item wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="0.5s">
                          <figure class="service-icon">
                              <img src="assets/images/app.svg" class="img-fluid" alt="Beinsys">
                          </figure>
                          <h4>Mobile App</h4>
                          <p>Get awesome for your product or service.</p>
                      </a>
                  </div>
                  <div class="col-md-6">
                    <a href="#" class="service-item top-spacing wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="0.5s">
                      <figure class="service-icon">
                        <img src="assets/images/branding.svg" class="img-fluid" alt="Beinsys">
                      </figure>
                      <h4>Branding</h4>
                      <p>Get awesome for your product or service.</p>
                    </a>
                      <a href="#" class="service-item wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="0.5s">
                          <figure class="service-icon">
                              <img src="assets/images/digital-marketing.svg" class="img-fluid" alt="Beinsys">
                          </figure>
                          <h4>Digital Marketing</h4>
                          <p>Get awesome for your product or service.</p>
                      </a>
                  </div>

                </div>
              </div>
              <div class="col-lg-3">
                <div class="service-content">
                  <article>
                    <h3 class="service-heading">Our Services</h3>
                    <p>Get awesome service for your product or service</p>
                    <a href="{{ URL::to('service')}}" class="service-more">All Services &nbsp; &nbsp; <span><i class="fas fa-arrow-right"></i></span></a>
                  </article>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="factory">
    <div class="factory-bgimage">
        <img src="assets/images/curve4.png" class="img-fluid" alt="">
        <div class="container factory-sliderbox">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="factory-slider">
                        <div class="factory-item text-center">
                            <figure>
                                <img src="assets/images/web-design-mockup.png" class="img-fluid" alt="Beinsys">
                                <figcaption>
                                    <h3>Web Design {web-factory}</h3>
                                    <p>
                                        lorem ipsum dollor sit amet, consecietur wel rhoncus lectus in elementum.
                                    </p>
                                </figcaption>
                            </figure>
                        </div>
                        {{-- <div class="factory-item text-center">
                            <figure>
                                <img src="assets/images/web-design-mockup.png" class="img-fluid" alt="Beinsys">
                                <figcaption>
                                    <h3>Web Design {web-factory}</h3>
                                    <p>
                                        lorem ipsum dollor sit amet, consecietur wel rhoncus lectus in elementum.
                                    </p>
                                </figcaption>
                            </figure>
                        </div>
                        <div class="factory-item text-center">
                            <figure>
                                <img src="assets/images/web-design-mockup.png" class="img-fluid" alt="Beinsys">
                                <figcaption>
                                    <h3>Web Design {web-factory}</h3>
                                    <p>
                                        lorem ipsum dollor sit amet, consecietur wel rhoncus lectus in elementum.
                                    </p>
                                </figcaption>
                            </figure>
                        </div> --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    </section>
    <section class="package">
      <div class="container">
        <div class="row">
          <div class="col-lg-10 offset-lg-1">
            <article class="text-center package-head">
              <h2 class="section-heading">Our Price</h2>
              <p>Get awesome service for your product or service</p>
            </article>
            <div class="row">
              <div class="col-lg-4">
                <div class="package-box text-center wow fadeInUp" data-wow-duration="2.5s" data-wow-delay="1.5s">
                  <article class="package-desc">
                    <h1 class="package-price">$30</h1>
                    <h4 class="package-name">Semi - Pro</h4>
                    <p>Monthly Package</p>
                  </article>
                  <ul class="package-list">
                    <li>8 Gb ram</li>
                    <li>500 GB Cloud Storage</li>
                    <li>Monthly Subscription</li>
                    <li>Responsive Frame work</li>
                    <li>Monthly Billing Software</li>
                    <li>1 Free Website</li>
                  </ul>
                  <button class="btn btn-outline">Get Started</button>
                </div>
              </div>
              <div class="col-lg-4 no-padder">
                <div class="package-box text-center package-professional wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.8s">
                  <article class="package-desc package-professional_desc">
                    <h1 class="package-price">$60</h1>
                    <h4 class="package-name">Professional</h4>
                    <p>Monthly Package</p>
                  </article>
                  <ul class="package-list">
                    <li>8 Gb ram</li>
                    <li>500 GB Cloud Storage</li>
                    <li>Monthly Subscription</li>
                    <li>Responsive Frame work</li>
                    <li>Monthly Billing Software</li>
                    <li>1 Free Website</li>
                  </ul>
                  <button class="btn btn-outline">Get Started</button>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="package-box text-center wow fadeInUp" data-wow-duration="2.5s" data-wow-delay="1.5s">
                  <article class="package-desc">
                    <h1 class="package-price">$90</h1>
                    <h4 class="package-name">Hyper - Pro</h4>
                    <p>Monthly Package</p>
                  </article>
                  <ul class="package-list">
                    <li>8 Gb ram</li>
                    <li>500 GB Cloud Storage</li>
                    <li>Monthly Subscription</li>
                    <li>Responsive Frame work</li>
                    <li>Monthly Billing Software</li>
                    <li>1 Free Website</li>
                  </ul>
                  <button class="btn btn-outline">Get Started</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="stats">
      <div class="container">
        <div class="row">
          <div class="col-lg-3">
            <div class="stats-box text-center">
              <figure class="stats-icon">
                <img src="assets/images/idea.svg" class="img-fluid" alt="Beinsys">
              </figure>
              <article>
                <h1 class="stats-number">243+</h1>
                <p class="stats-heading">Completed Projects</p>
              </article>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="stats-box text-center">
              <figure class="stats-icon">
                <img src="assets/images/cctv-headquarters.svg" class="img-fluid" alt="Beinsys">
              </figure>
              <article>
                <h1 class="stats-number">21</h1>
                <p class="stats-heading">Headquarters</p>
              </article>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="stats-box text-center">
              <figure class="stats-icon">
                <img src="assets/images/team.svg" class="img-fluid" alt="Beinsys">
              </figure>
              <article>
                <h1 class="stats-number">178k</h1>
                <p class="stats-heading">Worldwide Users</p>
              </article>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="stats-box text-center">
              <figure class="stats-icon">
                <img src="assets/images/coffee.svg" class="img-fluid" alt="Beinsys">
              </figure>
              <article>
                <h1 class="stats-number">128k</h1>
                <p class="stats-heading">Splended Coffees</p>
              </article>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="feature">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="feature-box text-center">
              <figure>
                <img src="assets/images/seo.png" class="img-fluid" alt="beinsys">
              </figure>
              <article class="feature-content">
                <h4>Basic Tips for SEO</h4>
                <p>lorem ipsum dollor sit amet, consecietur wel rhoncus lectus in elementum.</p>
                <a href="#" class="btn btn-more">Read More</a>
              </article>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="feature-box text-center">
              <figure>
                <img src="assets/images/Web-design-trends.png" class="img-fluid" alt="beinsys">
              </figure>
              <article class="feature-content">
                <h4>Web Design</h4>
                <p>lorem ipsum dollor sit amet, consecietur wel rhoncus lectus in elementum.</p>
                <a href="#" class="btn btn-more">Read More</a>
              </article>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="feature-box text-center">
              <figure>
                <img src="assets/images/digitalmarketing.png" class="img-fluid" alt="beinsys">
              </figure>
              <article class="feature-content">
                <h4>Digital Marketing</h4>
                <p>lorem ipsum dollor sit amet, consecietur wel rhoncus lectus in elementum.</p>
                <a href="#" class="btn btn-more">Read More</a>
              </article>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="testimonial">
        <div class="testimonial-bgimage">
            <img src="assets/images/curve4.png" class="img-fluid" alt="beinsys">
            <div class="container testimonial-slidebox">
                <div class="row">
                    <div class="testimonial-slider text-center">
                        <div class="testimonial-item">
                            <div class="testimonial-image" style="background-image:url(assets/images/profile-image.png)">
                                <!--<img src="assets/images/profile-image.png">-->
                            </div>
                            <article class="testimonial-content">
                                <h3>John Harison</h3>
                                <p>Ceo - Apple Company</p>
                                <p>lorem ipsum dollor sit amet, consecietur adpicing elit. phasellus wel rhoncus lectus in elementum.</p>
                            </article>
                        </div>
                        {{-- <div class="testimonial-item">
                            <div class="testimonial-image" style="background-image:url(assets/images/profile-image.png)">
                                <!--<img src="assets/images/profile-image.png">-->
                            </div>
                            <article class="testimonial-content">
                                <h3>John Harison</h3>
                                <p>Ceo- Apple Company</p>
                                <p>lorem ipsum dollor sit amet, consecietur adpicing elit. phasellus wel rhoncus lectus in elementum.</p>
                            </article>
                        </div>
                        <div class="testimonial-item">
                            <figure class="testimonial-image">
                                <img src="assets/images/profile-image.png">
                            </figure>
                            <article class="testimonial-content">
                                <h3>John Harison</h3>
                                <p>Ceo- Apple Company</p>
                                <p>lorem ipsum dollor sit amet, consecietur adpicing elit. phasellus wel rhoncus lectus in elementum.</p>
                            </article>
                        </div> --}}
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="partners">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="partners-content d-flex justify-content-around">
                        <figure class="partners-image d-flex justify-content-center"><img src="assets/images/logo28.png" class="img-fluid" alt="beinsys"></figure>
                        <figure class="partners-image d-flex justify-content-center"><img src="assets/images/eagle-logo-template-black-and-white-png-18.png" class="img-fluid" alt="beinsys"></figure>
                        <figure class="partners-image d-flex justify-content-center"><img src="assets/images/vegan-symbols-header.png" class="img-fluid" alt="beinsys"></figure>
                        <figure class="partners-image d-flex justify-content-center"><img src="assets/images/mobile-logo.png" class="img-fluid" alt="beinsys"></figure>
                        <figure class="partners-image d-flex justify-content-center"><img src="assets/images/logo46.png" class="img-fluid" alt="beinsys"></figure>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="newsletter">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="newsletter-block text-center">
                        <article>
                            <h3>Sign up to our Newsletter</h3>
                            <p>Get awesome service for your product or service</p>
                        </article>
                        <div class="newsletter-form">
                            <form action="{{ url('about') }}" method="POST" class="form-inline">
                                {{ csrf_field() }}
                                <div class="form-group">
                                    <input type="email" class="form-control formbox" name="email" id="email">
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    <img src="assets/images/paper-plane.svg" class="img-fluid" alt="beinsys">
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection

