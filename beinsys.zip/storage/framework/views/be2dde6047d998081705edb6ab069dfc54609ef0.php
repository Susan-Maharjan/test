<?php $__env->startSection('content'); ?>
        <section class="template contact-template">
            <div class="template-container" style="background-image:url('assets/images/about-bg.png')">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <article class="template-content">
                                <h1>Lets build something great together.</h1>
                                <a href="#" class="btn btn-white">Talk to Us</a>
                            </article>
                        </div>
                        <div class="col-lg-6">
                            <figure class="template-image">
                                <img src="assets/images/banner-svg.svg" class="img-fluid" alt="beinsys">
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="contact">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 offset-lg-1">
                        <h3 class="contact-heading">Contact Us</h3>
                        <form action="<?php echo e(url('contact')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group form-wrap">
                                <label for="name">Name</label>
                                <input type="text" class="form-control form-box" id="name" name="name" placeholder="">
                            </div>
                            <div class="form-group form-wrap">
                                <label for="email">Email address</label>
                                <input type="email" class="form-control form-box" id="email" name="email" placeholder="">
                            </div>
                            <div class="form-group form-wrap">
                                <label for="name">Number</label>
                                <input type="text" class="form-control form-box" id="number" name="number" placeholder="">
                            </div>
                            <div class="form-group form-wrap">
                                <label for="name">Address</label>
                                <input type="text" class="form-control form-box" id="address" name="address" placeholder="">
                            </div>
                            <div class="form-group form-wrap">
                                <label for="name">Field</label>
                                <input type="text" class="form-control form-box" id="field" name="field" placeholder="">
                            </div>
                            <div class="form-group form-wrap">
                                <label for="message">Message</label>
                                <textarea class="form-control form-box" id="message" name="message" rows="3"></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                    <div class="col-lg-6">
                        <div class="contact-address">
                            <address>
                                <span>BEINSYS</span><br>
                                1702 Olympic Blvd Santa Monica, CA 90404 <br>
                                +91554866458, 91554855865 <br>
                                info@beinsys.com
                            </address>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\beinsys\resources\views/contact.blade.php ENDPATH**/ ?>