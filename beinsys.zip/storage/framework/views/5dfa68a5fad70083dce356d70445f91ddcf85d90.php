<?php $__env->startSection('content'); ?>
    <section class="template pricing">
        <div class="template-container" style="background-image:url('assets/images/about-bg.png')">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 offset-lg-1">
                        <article class="template-content">
                            <h1>You take care of your Bussiness, we take care of your website.</h1>
                            <p>Blanditiis pellentesque Interdum lorem Cras porta, amet nam, animi lectus autem magnam! Venenatis nonummy labore interdum, excepteur lacinia litora, taciti, sint! Placerat numquam reiciendis.</p>
                            <a href="#" class="btn btn-white">Select Package</a>
                            <a href="#" class="btn btn-white">Learn More</a>
                        </article>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="package pricing-package">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <article class="text-center package-head">
                        <h2 class="section-heading">Our Price</h2>
                        <p>Get awesome service for your product or service</p>
                    </article>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="package-box text-center">
                                <article>
                                    <h1 class="package-price">$30</h1>
                                    <h4 class="package-name">Semi-Pro</h4>
                                    <p>Monthly Package</p>
                                </article>
                                <ul class="package-list">
                                    <li>8 Gb ram</li>
                                    <li>500 GB Cloud Storage</li>
                                    <li>Monthly Subscription</li>
                                    <li>Responsive Frame work</li>
                                    <li>Monthly Billing Software</li>
                                    <li>1 Free Website</li>
                                </ul>
                                <button class="btn btn-outline">Get Started</button>
                            </div>
                        </div>
                        <div class="col-lg-4 no-padder">
                            <div class="package-box text-center package-professional">
                                <article>
                                    <h1 class="package-price">$60</h1>
                                    <h4 class="package-name">Professional</h4>
                                    <p>Monthly Package</p>
                                </article>
                                <ul class="package-list">
                                    <li>8 Gb ram</li>
                                    <li>500 GB Cloud Storage</li>
                                    <li>Monthly Subscription</li>
                                    <li>Responsive Frame work</li>
                                    <li>Monthly Billing Software</li>
                                    <li>1 Free Website</li>
                                </ul>
                                <button class="btn btn-outline">Get Started</button>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="package-box text-center">
                                <article>
                                    <h1 class="package-price">$90</h1>
                                    <h4 class="package-name">Hyper - Pro</h4>
                                    <p>Monthly Package</p>
                                </article>
                                <ul class="package-list">
                                    <li>8 Gb ram</li>
                                    <li>500 GB Cloud Storage</li>
                                    <li>Monthly Subscription</li>
                                    <li>Responsive Frame work</li>
                                    <li>Monthly Billing Software</li>
                                    <li>1 Free Website</li>
                                </ul>
                                <button class="btn btn-outline">Get Started</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="pricing-table">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <article class="text-center">
                        <h2 class="section-heading">Choose the right plan for your business.</h2>
                        <p>Get awesome service for your product or service</p>
                    </article>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col"></th>
                                <th scope="col">Semi-Pro</th>
                                <th scope="col">Professional</th>
                                <th scope="col">Hyper-Pro</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="pricing-item">8 Gb ram</td>
                                <td></td>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                            </tr>
                            <tr>
                                <td class="pricing-item">500 GB Cloud Storage</td>
                                <td><i class="fas fa-check"></i></td>
                                <td></td>
                                <td><i class="fas fa-check"></i></td>
                            </tr>
                            <tr>
                                <td class="pricing-item">Monthly Subscription</td>
                                <td></td>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                            </tr>
                            <tr>
                                <td class="pricing-item">Responsive Frame work</td>
                                <td></td>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                            </tr>
                            <tr>
                                <td class="pricing-item">Monthly Billing Software</td>
                                <td><i class="fas fa-check"></i></td>
                                <td></td>
                                <td><i class="fas fa-check"></i></td>
                            </tr>
                            <tr>
                                <td class="pricing-item">1 Free Website</td>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                                <td><i class="fas fa-check"></i></td>
                            </tr>
                            <tr>
                                <th class="pricing-item"><h4>Total Per Month</h4></th>
                                <td><h3 class="pricing-total">$30</h3></td>
                                <td><h3 class="pricing-total">$60</h3></td>
                                <td><h3 class="pricing-total">$90</h3></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\beinsys\resources\views/price.blade.php ENDPATH**/ ?>