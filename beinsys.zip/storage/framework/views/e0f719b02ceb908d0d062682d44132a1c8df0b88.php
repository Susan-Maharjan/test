<?php $__env->startSection('content'); ?>
    <section class="template">
        <div class="template-container" style="background-image:url('assets/images/about-bg.png')">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <article class="template-content">
                            <h1>Our Services</h1>
                            <p>Blanditiis pellentesque Interdum lorem Cras porta, amet nam, animi lectus autem magnam! Venenatis nonummy labore interdum, excepteur lacinia litora, taciti, sint! Placerat numquam reiciendis.</p>
                        </article>
                    </div>
                    <div class="col-lg-4">
                        <figure class="template-image">
                            <img src="assets/images/banner-svg.svg" class="img-fluid" alt="beinsys">
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 no-padder">
                    <a href="#" class="service-item">
                        <figure class="service-icon">
                            <img src="assets/images/web.svg" class="img-fluid" alt="Beinsys">
                        </figure>
                        <h4>Web Development</h4>
                        <p>Get awesome for your product or service.</p>
                    </a>
                </div>
                <div class="col-lg-4 no-padder">
                    <a href="#" class="service-item">
                        <figure class="service-icon">
                            <img src="assets/images/app.svg" class="img-fluid" alt="Beinsys">
                        </figure>
                        <h4>Mobile App</h4>
                        <p>Get awesome for your product or service.</p>
                    </a>
                </div>
                <div class="col-lg-4 no-padder">
                    <a href="#" class="service-item top-spacing">
                        <figure class="service-icon">
                            <img src="assets/images/branding.svg" class="img-fluid" alt="Beinsys">
                        </figure>
                        <h4>Branding</h4>
                        <p>Get awesome for your product or service.</p>
                    </a>
                </div>
                <div class="col-lg-4 no-padder">
                    <a href="#" class="service-item">
                        <figure class="service-icon">
                            <img src="assets/images/digital-marketing.svg" class="img-fluid" alt="Beinsys">
                        </figure>
                        <h4>Digital Marketing</h4>
                        <p>Get awesome for your product or service.</p>
                    </a>
                </div>
                <div class="col-lg-4 no-padder">
                    <a href="#" class="service-item">
                        <figure class="service-icon">
                            <img src="assets/images/web.svg" class="img-fluid" alt="Beinsys">
                        </figure>
                        <h4>Web Development</h4>
                        <p>Get awesome for your product or service.</p>
                    </a>
                </div>
                <div class="col-lg-4 no-padder">
                    <a href="#" class="service-item">
                        <figure class="service-icon">
                            <img src="assets/images/app.svg" class="img-fluid" alt="Beinsys">
                        </figure>
                        <h4>Mobile App</h4>
                        <p>Get awesome for your product or service.</p>
                    </a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\beinsys\resources\views/service.blade.php ENDPATH**/ ?>