<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GeoDetails extends Model
{
    protected $fillable = ['ip_num', 'ip_vers', 'ip_add', 'country_code', 'region_name', 'city_name', 'lat', 'long', 'time', 'zip'];
}
