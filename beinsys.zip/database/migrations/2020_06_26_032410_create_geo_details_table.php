<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGeoDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('geo_details', function (Blueprint $table) {
            $table->increments('id');
            $table->string('ip_num');
            $table->string('ip_vers');
            $table->string('ip_add');
            $table->string('country_code');
            $table->string('region_name');
            $table->string('city_name');
            $table->string('lat');
            $table->string('long');
            $table->string('time');
            $table->string('zip');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('geo_details');
    }
}
